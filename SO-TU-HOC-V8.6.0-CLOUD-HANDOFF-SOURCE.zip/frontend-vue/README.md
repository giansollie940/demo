# SỔ TỰ HỌC V8.6.0 — Vue Migration CP2

This folder is the parallel Vue 3 + TypeScript + Vite frontend. The existing `../frontend/` vanilla application remains the rollback/production frontend during migration.

## Implemented in CP1

- Vue 3 + TypeScript + Vite project structure.
- Vue Router with hash history for GitHub Pages.
- Pinia auth/context/preferences stores.
- TanStack Vue Query client and current-week query/prefetch.
- Typed bridge to the existing `window.SupabaseService`; no database/RLS/RPC/Edge Function changes.
- Responsive AppShell with always-visible Lucide icons.
- Light/dark theme with persisted preference and reduced-motion support.
- Redesigned login page using existing favicon/login hero.
- Dashboard checkpoint using Vue Query week data.
- Rolling week lifecycle as a pure module: after the final study session ends, the operational week advances immediately; the operational week and following week are open.
- Central realtime invalidation entrypoint (query invalidation, not manual DOM mutation).
- Placeholder routes for pages not yet migrated, so route/permission architecture is fixed before moving business UI.
- Weekly Management page with lifecycle summaries, holiday/deadline editing, admin-only Week 1 rebase, filtering, and dirty-state protection.
- Default and week-specific Schedule editor with safe override preservation, mobile day tabs, realtime conflict handling, and reset-to-default confirmation.

## Not migrated yet

Registration, teacher approval, class tracking details, student management, statistics, history/comments, Root Admin, settings and Owl remain to be migrated page-by-page in later checkpoints.

## Backend compatibility

`public/supabase-service.js` is byte-identical to the V8.5.3f vanilla frontend bridge. V8.6.0 CP1 does not change the database schema, RLS, RPC, Edge Functions, Auth model, AI review logic, or root-admin transfer rules.

## Local setup

1. Copy your existing public browser config to `public/config.js` (do not put service-role secrets in it).
2. Install dependencies:
   `npm install`
3. Start dev server:
   `npm run dev`
4. Run tests/build:
   `npm run typecheck && npm test && npm run test:unit && npm run build`

If a restricted sandbox blocks Vite's default config bundler, use `vite build --configLoader runner` after `npm run typecheck`. This is an environment workaround; the normal production command remains `npm run build`.

## GitHub Pages

Vite uses `base: './'` and Vue Router uses hash history. During migration, deploy this frontend under a parallel path such as `/tu-hoc/vue/` rather than replacing `/tu-hoc/`.
