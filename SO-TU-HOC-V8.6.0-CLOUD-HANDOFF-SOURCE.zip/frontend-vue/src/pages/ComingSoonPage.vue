<script setup lang="ts">
import { useRoute } from 'vue-router'
import AppCard from '../components/ui/AppCard.vue'

const route = useRoute()
</script>
<template><div class="page-stack"><header class="page-header"><div><h1>{{ route.meta.title||'Đang chuyển sang Vue' }}</h1><p>Trang này vẫn dùng backend hiện tại và sẽ được chuyển renderer theo checkpoint tiếp theo.</p></div></header><AppCard padding="lg"><h2>Migration in progress</h2><p class="muted">Bản vanilla V8.5.3f vẫn được giữ nguyên để rollback. Không có thay đổi database/RLS/Edge Functions ở checkpoint này.</p></AppCard></div></template>
