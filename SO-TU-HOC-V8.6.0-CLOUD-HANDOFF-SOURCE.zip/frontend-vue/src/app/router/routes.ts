import type { RouteRecordRaw } from 'vue-router'
import AppShell from '../../layouts/AppShell.vue'
import ComingSoonPage from '../../pages/ComingSoonPage.vue'
import DashboardPage from '../../pages/DashboardPage.vue'
import LoginPage from '../../pages/LoginPage.vue'
import RegistrationPage from '../../pages/RegistrationPage.vue'
import SchedulePage from '../../pages/SchedulePage.vue'
import WeeksPage from '../../pages/WeeksPage.vue'
import type { UserRole } from '../../types/legacy'

const managers: UserRole[] = ['teacher', 'admin']

export const routes: RouteRecordRaw[] = [
  { path: '/login', component: LoginPage, meta: { public: true, title: 'Đăng nhập' } },
  {
    path: '/',
    component: AppShell,
    children: [
      { path: '', redirect: '/dashboard' },
      { path: 'dashboard', component: DashboardPage, meta: { title: 'Tổng quan' } },
      { path: 'register', component: RegistrationPage, meta: { title: 'Đăng ký tự học' } },
      { path: 'review', component: ComingSoonPage, meta: { title: 'Duyệt đăng ký', roles: managers } },
      { path: 'tracking', component: ComingSoonPage, meta: { title: 'Theo dõi cả lớp', roles: ['monitor', ...managers] } },
      { path: 'weeks', component: WeeksPage, meta: { title: 'Quản lý tuần', roles: managers } },
      { path: 'schedule', component: SchedulePage, meta: { title: 'Thời khóa biểu', roles: managers } },
      { path: 'students', component: ComingSoonPage, meta: { title: 'Học sinh', roles: managers } },
      { path: 'statistics', component: ComingSoonPage, meta: { title: 'Thống kê', roles: managers } },
      { path: 'history', component: ComingSoonPage, meta: { title: 'Lịch sử' } },
      { path: 'comments', component: ComingSoonPage, meta: { title: 'Nhận xét GV' } },
      { path: 'admin', component: ComingSoonPage, meta: { title: 'Quản trị', roles: ['admin'] } },
      { path: 'settings', component: ComingSoonPage, meta: { title: 'Cài đặt' } },
    ],
  },
  { path: '/:pathMatch(.*)*', redirect: '/dashboard' },
]
