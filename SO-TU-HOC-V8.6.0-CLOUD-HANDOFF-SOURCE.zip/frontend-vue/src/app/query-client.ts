import { QueryClient } from '@tanstack/vue-query'

export const queryClient=new QueryClient({
  defaultOptions:{
    queries:{
      staleTime:30_000,
      gcTime:10*60_000,
      retry:1,
      refetchOnWindowFocus:true,
    },
  },
})
