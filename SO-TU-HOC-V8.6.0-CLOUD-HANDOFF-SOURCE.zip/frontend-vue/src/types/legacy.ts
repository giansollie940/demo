export type UserRole = 'student' | 'monitor' | 'teacher' | 'admin'

export interface CurrentUser {
  id: string
  code: string
  name: string
  role: UserRole
  classId: string | null
  active: boolean
  deletedAt?: string | null
}

export interface SchoolClass {
  id: string
  schoolYearId?: string | null
  code: string
  name: string
  active: boolean
}

export interface WeekRecord {
  id: string
  number: number
  startDate: string
  endDate: string
  status?: string
  deadlineMode?: 'per_session_20' | 'specific' | string
  deadline?: string
  note?: string
}

export interface PeriodRecord {
  n: number
  start: string
  end: string
}

export interface ScheduleSlot {
  dow: number
  period: number
}

export interface ScheduleOverride extends ScheduleSlot {
  id?: string
  classId?: string | null
  weekId: string
  active?: boolean
  reason?: string
}

export interface RegistrationRecord {
  id: string
  classId?: string | null
  studentId: string
  weekId: string
  dow: number
  period: number
  content: string
  note?: string
  status: string
  teacherComment?: string
  usesElectronicDevice?: boolean
  approvalSource?: 'manual' | 'ai' | string
  autoReviewReason?: string
  aiReviewStatus?: string
  aiDecision?: string
  aiCategory?: string
  aiConfidence?: number | null
  aiRevisionStatus?: string
  aiRevisionConfidence?: number | null
  aiReason?: string
  aiModel?: string
  aiReviewedAt?: string | null
  aiReviewCount?: number
  isEmergency?: boolean
  emergencyReason?: string
  emergencyRequestedAt?: string | null
  deviceDetectionSource?: string
  deviceDetectionConfidence?: number | null
  revisionOverdueAt?: string | null
  approvedAt?: number | null
  updatedAt?: number
  [key: string]: unknown
}

export interface EmergencyRegistrationInput {
  weekId: string
  dow: number
  period: number
  content: string
  note?: string
  reason: string
  usesElectronicDevice?: boolean
}

export interface WeekData {
  overrides: ScheduleOverride[]
  registrations: RegistrationRecord[]
}

export interface LegacyState {
  version: number
  activeSchoolYearId: string | null
  activeClassId: string | null
  availableClasses: SchoolClass[]
  settings: Record<string, unknown> & {
    className?: string
    schoolYear?: string
    teacherName?: string
    announcement?: string
    registrationDeadlineTime?: string
  }
  users: CurrentUser[]
  weeks: WeekRecord[]
  periods: PeriodRecord[]
  schedule: ScheduleSlot[]
  overrides: WeekData['overrides']
  registrations: RegistrationRecord[]
  notifications: unknown[]
  currentWeekId: string | null
  [key: string]: unknown
}

export interface LoadStateResult {
  currentUser: CurrentUser | null
  state: LegacyState | null
}

export interface RealtimeChange {
  table?: string
  deleted?: boolean
  structural?: boolean
  record?: Record<string, unknown>
  [key: string]: unknown
}

export interface LegacySupabaseService {
  enabled(): boolean
  init(): Promise<unknown>
  signInCode(code: string, password: string): Promise<unknown>
  signOut(): Promise<void>
  loadState(preferredClassId?: string | null): Promise<LoadStateResult>
  loadWeekData(weekId: string, classId?: string | null): Promise<WeekData>
  syncState(state: LegacyState, currentUser: CurrentUser): Promise<void>
  teacherRebaseWeeks(firstWeekStart: string, deadlineTime?: string): Promise<unknown>
  requestRegistrationRevision(registrationId: string, teacherComment: string): Promise<boolean>
  emergencyRegister(input: EmergencyRegistrationInput): Promise<RegistrationRecord | null>
  requestAiReview(registrationId: string): Promise<unknown>
  prepareSessionAiRereview(input: { classId: string; weekId: string; dow: number; period: number }): Promise<string[]>
  prepareRegistrationAiRereview(registrationId: string): Promise<boolean>
  deleteRegistration(registrationId: string): Promise<boolean>
  markNotificationsRead(ids: string[]): Promise<void>
  resetSnapshot(state: LegacyState): void
  setActiveClassId(userId: string, classId: string): void
  getDailyQuote(): Promise<unknown>
  subscribeRealtime(
    onChange: (change: RealtimeChange) => void,
    onStatus?: (status: string, error?: unknown) => void,
  ): Promise<unknown> | unknown
  unsubscribeRealtime(): Promise<void> | void
}
