# SỔ TỰ HỌC Vue Migration — Agent Guide

## Working directory

Run frontend commands from `frontend-vue/`.

## Setup

```bash
cd frontend-vue
npm ci
```

`public/config.js` is intentionally excluded from Git. Do not recreate it from secrets and do not print configuration values. Static/unit/type/build work does not require the live file.

## Required verification

```bash
cd frontend-vue
npm run typecheck
npm test
npm run test:unit
npm run build
```

If a restricted container blocks Vite's default config bundler, run:

```bash
npm run typecheck
./node_modules/.bin/vite build --configLoader runner
```

Record the exact command and exit code; never claim an unrun build.

## Architecture and constraints

- Read `docs/superpowers/specs/2026-08-24-v860-complete-vue-migration-design.md` first.
- Keep `public/supabase-service.js` as the backend bridge.
- Do not modify PostgreSQL schema, RLS, grants, RPC, Auth, Edge Functions, or AI decision contracts.
- Keep Vue Router hash history and Vite `base: './'`.
- Pinia owns auth/context/preferences; Vue Query owns server data.
- Realtime invalidates/refetches canonical state.
- Preserve the vanilla deployment as rollback until final cutover.

## Current handoff state

- CP1 complete.
- CP2 Weekly Management + Schedule complete and verified.
- CP3 Registration/AI Tasks 1–5 complete.
- Continue at CP3 Task 6 in `docs/superpowers/plans/2026-08-25-v860-cp3-registration-ai.md`.
- `frontend-vue/tests/unit/approval-components.spec.ts` is the intentional RED test.
- Implement `ApprovalFilters.vue`, `ApprovalList.vue`, `ApprovalDetail.vue`, and `ApprovalPage.vue`, then replace the `/review` placeholder.

Use TDD: confirm the existing RED, write minimal production code, then rerun the focused test, full unit suite, typecheck, and build.

