# V8.6.0 CP2 Weekly Management and Schedule Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the `/weeks` and `/schedule` placeholders with production Vue pages that preserve legacy behavior while making week-specific schedules safe and independent.

**Architecture:** Pure TypeScript models normalize and apply week/schedule drafts to cloned `LegacyState`; an injected mutation runtime calls the existing `SupabaseService.syncState`/`teacherRebaseWeeks`, reloads canonical state, hydrates context, and invalidates Vue Query. Pages own only local drafts and never mutate `auth.legacyState` while editing.

**Tech Stack:** Vue 3, TypeScript, Pinia, TanStack Vue Query, Vue Router, Vitest, Node test runner, Lucide Vue, existing Supabase bridge.

**Spec:** `docs/superpowers/specs/2026-08-24-v860-complete-vue-migration-design.md`

## Global Constraints

- Do not modify PostgreSQL schema, RLS, grants, RPC, Auth behavior, Edge Functions, AI-review contracts, or root-admin uniqueness.
- Preserve `public/config.js` without printing its values.
- Default-schedule saves preserve all week-specific overrides.
- Week-specific schedule saves and resets affect only the selected week.
- Students and monitors cannot access management routes.
- Only admins can rebase the Week 1 calendar.
- Every production-code change follows a RED/GREEN cycle.
- This extracted workspace has no Git metadata; replace commit steps with a changed-file SHA-256 checkpoint.

---

### Task 1: Add CP2 typed contracts and unit-test runner

**Files:**
- Modify: `frontend-vue/package.json`
- Modify: `frontend-vue/src/types/legacy.ts`
- Create: `frontend-vue/tests/unit/contracts.spec.ts`

**Interfaces:**
- Consumes: existing `LegacyState`, `CurrentUser`, `ScheduleSlot`, `WeekData`.
- Produces: `ScheduleOverride`, typed `syncState`, typed `teacherRebaseWeeks`, and `npm run test:unit`.

- [ ] **Step 1: Write the failing contract test**

```ts
import { describe, expect, it } from 'vitest'
import type { LegacySupabaseService, ScheduleOverride } from '../../src/types/legacy'

describe('CP2 contracts', () => {
  it('requires a week id on schedule overrides', () => {
    const row: ScheduleOverride = { weekId: 'week-1', dow: 0, period: 1, active: true }
    expect(row.weekId).toBe('week-1')
  })
  it('exposes state synchronization and calendar rebase methods', () => {
    const names: Array<keyof LegacySupabaseService> = ['syncState', 'teacherRebaseWeeks']
    expect(names).toEqual(['syncState', 'teacherRebaseWeeks'])
  })
})
```

- [ ] **Step 2: Run RED**

Run: `npm exec vitest -- run tests/unit/contracts.spec.ts`

Expected: TypeScript collection failure because `ScheduleOverride`, `syncState`, and `teacherRebaseWeeks` are not declared.

- [ ] **Step 3: Add minimal types**

```ts
export interface ScheduleOverride extends ScheduleSlot {
  id?: string
  classId?: string | null
  weekId: string
  active?: boolean
  reason?: string
}

syncState(state: LegacyState, currentUser: CurrentUser): Promise<void>
teacherRebaseWeeks(firstWeekStart: string, deadlineTime?: string): Promise<unknown>
```

Change `WeekData.overrides` to `ScheduleOverride[]` and add:

```json
"test:unit": "vitest run tests/unit"
```

- [ ] **Step 4: Run GREEN**

Run: `npm run test:unit`

Expected: PASS.

- [ ] **Step 5: Record checkpoint**

Run SHA-256 for the three changed files and append the hashes to the CP2 progress ledger.

---

### Task 2: Implement pure schedule model

**Files:**
- Create: `frontend-vue/src/features/schedule/schedule-model.ts`
- Create: `frontend-vue/tests/unit/schedule-model.spec.ts`

**Interfaces:**
- Consumes: `LegacyState`, `PeriodRecord`, `ScheduleSlot`, `ScheduleOverride`.
- Produces:
  - `normalizeScheduleSlots(slots, periods): ScheduleSlot[]`
  - `effectiveScheduleForWeek(state, weekId): ScheduleSlot[]`
  - `createWeekScheduleDraft(state, weekId): ScheduleSlot[]`
  - `applyDefaultSchedule(state, slots): LegacyState`
  - `applyWeekSchedule(state, classId, weekId, slots): LegacyState`
  - `resetWeekSchedule(state, weekId): LegacyState`
  - `diffSchedule(base, candidate): { added; removed }`

- [ ] **Step 1: Write failing behavior tests**

Test literal fixtures for dedupe/sort, invalid day, missing period, empty schedule, default-save override preservation, week-X save preserving week-Y, and selected-week reset.

```ts
expect(normalizeScheduleSlots([
  { dow: 2, period: 3 }, { dow: 0, period: 1 }, { dow: 2, period: 3 },
], periods)).toEqual([{ dow: 0, period: 1 }, { dow: 2, period: 3 }])
```

- [ ] **Step 2: Run RED**

Run: `npm exec vitest -- run tests/unit/schedule-model.spec.ts`

Expected: module-not-found.

- [ ] **Step 3: Implement normalization and immutable apply/reset helpers**

Use `structuredClone(state)`, exact `weekId` filtering, stable `dow/period` sorting, and descriptive validation errors.

- [ ] **Step 4: Run GREEN**

Run: `npm exec vitest -- run tests/unit/schedule-model.spec.ts`

Expected: all schedule-model tests pass.

- [ ] **Step 5: Record checkpoint hashes**

Hash the model and test files.

---

### Task 3: Implement pure week editor model

**Files:**
- Create: `frontend-vue/src/features/weeks/week-editor-model.ts`
- Create: `frontend-vue/tests/unit/week-editor-model.spec.ts`

**Interfaces:**
- Produces:
  - `WeekEditorDraft`
  - `buildWeekDrafts(weeks): WeekEditorDraft[]`
  - `validateWeekDrafts(drafts): void`
  - `applyWeekDrafts(state, drafts): LegacyState`
  - `validateWeek1Start(date): void`
  - `summarizeWeekStatuses(...)`

- [ ] **Step 1: Write failing tests**

Cover specific-deadline requirement, per-session deadline clearing, holiday persistence, Monday validation, immutable state application, and lifecycle summary counts.

- [ ] **Step 2: Run RED**

Run: `npm exec vitest -- run tests/unit/week-editor-model.spec.ts`

Expected: module-not-found.

- [ ] **Step 3: Implement minimal pure model**

Keep automatic operational status separate from explicit holiday status.

- [ ] **Step 4: Run GREEN**

Run the single spec and then `npm run test:unit`.

- [ ] **Step 5: Record checkpoint hashes**

Hash model and tests.

---

### Task 4: Implement injected legacy mutation runtime

**Files:**
- Create: `frontend-vue/src/features/shared/legacy-mutation.ts`
- Create: `frontend-vue/src/features/schedule/schedule-mutations.ts`
- Create: `frontend-vue/src/features/weeks/week-mutations.ts`
- Create: `frontend-vue/tests/unit/legacy-mutations.spec.ts`

**Interfaces:**
- Produces:

```ts
export interface LegacyMutationRuntime {
  service: Pick<LegacySupabaseService, 'syncState' | 'teacherRebaseWeeks'>
  currentUser: CurrentUser
  getState(): LegacyState
  reload(classId: string): Promise<LegacyState>
  hydrate(state: LegacyState): void
  invalidate(): Promise<void>
}

export async function commitStateMutation(
  runtime: LegacyMutationRuntime,
  classId: string,
  buildNext: (state: LegacyState) => LegacyState,
): Promise<LegacyState>
```

- [ ] **Step 1: Write failing mutation tests**

Use a complete in-memory runtime. Assert call order `sync → reload → hydrate → invalidate`, source immutability, no reload on sync failure, and exact preservation rules.

- [ ] **Step 2: Run RED**

Run: `npm exec vitest -- run tests/unit/legacy-mutations.spec.ts`

- [ ] **Step 3: Implement minimal runtime and wrappers**

Schedule wrappers call Task 2 pure functions. Week wrappers call Task 3 pure functions. Rebase calls `teacherRebaseWeeks` only after role/date validation.

- [ ] **Step 4: Run GREEN**

Run mutation spec and all unit tests.

- [ ] **Step 5: Record checkpoint hashes**

Hash runtime, wrappers, and tests.

---

### Task 5: Add shared tabs, dialog, and save-status UI

**Files:**
- Create: `frontend-vue/src/components/ui/AppTabs.vue`
- Create: `frontend-vue/src/components/ui/ConfirmDialog.vue`
- Create: `frontend-vue/src/components/ui/InlineStatus.vue`
- Create: `frontend-vue/tests/unit/ui-model.spec.ts`

**Interfaces:**
- `AppTabs` consumes items, active id, and emits `update:modelValue`.
- `ConfirmDialog` consumes title/body/confirmLabel/danger/open and emits confirm/cancel.
- `InlineStatus` renders saving/success/error/server-changed states.

- [ ] **Step 1: Add failing pure tests for tab selection and dialog action descriptors**
- [ ] **Step 2: Run RED**
- [ ] **Step 3: Implement accessible components with real buttons, focus restoration, Escape cancel, and reduced motion**
- [ ] **Step 4: Run typecheck and unit tests**
- [ ] **Step 5: Record checkpoint hashes**

---

### Task 6: Build Schedule page

**Files:**
- Create: `frontend-vue/src/components/schedule/ScheduleGrid.vue`
- Create: `frontend-vue/src/components/schedule/ScheduleModeTabs.vue`
- Create: `frontend-vue/src/pages/SchedulePage.vue`
- Modify: `frontend-vue/src/app/router/index.ts`
- Create: `frontend-vue/tests/schedule-page.test.mjs`

**Interfaces:**
- ScheduleGrid consumes periods/slots/readOnly/mobileDay and emits `toggle`.
- SchedulePage uses the mutation runtime and Task 2 model.

- [ ] **Step 1: Write failing route/source contract and dirty-state model tests**

Require `/schedule` to import `SchedulePage`, `aria-pressed`, default/week tabs, create-from-default, and reset confirmation.

- [ ] **Step 2: Run RED**

Run Node contract plus unit tests.

- [ ] **Step 3: Implement responsive grid and page**

Desktop matrix, mobile day tabs, selected-count summary, diff summary, dirty guard, no optimistic success, and week-specific safety rules.

- [ ] **Step 4: Run GREEN**

Run schedule contract, unit tests, typecheck, and production build.

- [ ] **Step 5: Record checkpoint hashes**

---

### Task 7: Build Weekly Management page

**Files:**
- Create: `frontend-vue/src/components/weeks/WeekStatusBadge.vue`
- Create: `frontend-vue/src/components/weeks/WeekEditorCard.vue`
- Create: `frontend-vue/src/components/weeks/WeekCalendarSetup.vue`
- Create: `frontend-vue/src/pages/WeeksPage.vue`
- Modify: `frontend-vue/src/app/router/index.ts`
- Create: `frontend-vue/tests/weeks-page.test.mjs`

**Interfaces:**
- WeeksPage consumes auth/context/lifecycle and Task 3/4 APIs.

- [ ] **Step 1: Write failing page/permission contracts**

Require real `/weeks` page, holiday/deadline controls, admin-only rebase source guard, current-week action, filters, and dirty-state handling.

- [ ] **Step 2: Run RED**
- [ ] **Step 3: Implement page and components**
- [ ] **Step 4: Run GREEN with Node contracts, unit tests, typecheck, and build**
- [ ] **Step 5: Record checkpoint hashes**

---

### Task 8: Realtime conflict handling and full CP2 verification

**Files:**
- Modify: `frontend-vue/src/realtime/useRealtimeInvalidation.ts`
- Create: `frontend-vue/src/features/shared/dirty-registry.ts`
- Create: `frontend-vue/tests/unit/dirty-registry.spec.ts`
- Create: `docs/superpowers/checkpoints/V8.6.0-CP2-STATUS.md`

**Interfaces:**
- Dirty registry lets active editors mark dirty/clean and receive structural-change notifications without global state replacement.

- [ ] **Step 1: Write RED tests for clean reload versus dirty server-change notification**
- [ ] **Step 2: Implement minimal dirty registry and integrate both pages/realtime**
- [ ] **Step 3: Run the complete suite**

```text
npm run typecheck
npm test
npm run test:unit
npm run build
```

If sandbox blocks Vite config bundling, run `npm run typecheck` followed by `vite build --configLoader runner` and record both exit codes.

- [ ] **Step 4: Inspect production `dist`**

Verify `config.js`, `config.example.js`, `supabase-service.js`, hashed JS/CSS, images, and no source/node_modules files.

- [ ] **Step 5: Package configured CP2 DIST**

Create `outputs/SO-TU-HOC-V8.6.0-CP2-DIST-CONFIGURED.zip`, read every ZIP entry, and record SHA-256 without printing config values.

- [ ] **Step 6: Write checkpoint status and changed-file manifest**

Document exact commands, exit codes, warnings, file counts, and remaining placeholders/routes for the next checkpoint.

