# SỔ TỰ HỌC V8.6.0 Vue Foundation + Auth Shell Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Introduce a parallel Vue 3 + TypeScript + Vite frontend that preserves the current Supabase backend and can progressively replace the vanilla renderer without cutting over production.

**Architecture:** Keep `frontend/` unchanged as rollback. Add `frontend-vue/` with Vue Router, Pinia, TanStack Vue Query and a typed bridge to the existing `window.SupabaseService`. Server state moves behind query keys while auth/class/week/UI preferences use Pinia. Hash routing and Vite `base: './'` keep GitHub Pages deployment safe.

**Tech Stack:** Vue 3, TypeScript, Vite, Vue Router, Pinia, TanStack Vue Query, VueUse, Lucide Vue, Supabase JS, Vitest, Playwright.

**Spec:** `/mnt/data/SO-TU-HOC-V8.5.0-VUE-MIGRATION-DESIGN.md`

## Global Constraints

- Do not modify PostgreSQL schema, RLS, RPC, Edge Functions, or AI-review contracts.
- Keep `frontend/` deployable and untouched except for later explicit cutover work.
- Reuse the current `supabase-service.js` as the first migration bridge; no duplicate backend semantics.
- Use hash history for GitHub Pages.
- Pinia owns auth/context/preferences only; Vue Query owns week/server data.
- Icons are always visible; support light/dark theme and `prefers-reduced-motion`.
- Login uses one hero image and does not overlay functional text on the image.
- No service role secrets in the browser.

---

### Task 1: Scaffold Vue/Vite project and migration bridge

**Files:**
- Create: `frontend-vue/package.json`, `frontend-vue/vite.config.ts`, TypeScript configs, `frontend-vue/index.html`
- Create: `frontend-vue/public/supabase-service.js`, `frontend-vue/public/config.example.js`, image assets
- Create: `frontend-vue/src/services/legacy-supabase.ts`, `frontend-vue/src/types/legacy.ts`
- Test: `frontend-vue/tests/cp1-structure.test.mjs`

**Interfaces:**
- Consumes: existing `window.SupabaseService` contract.
- Produces: typed `legacyApi` bridge used by stores and queries.

- [ ] Write structure/contract test and verify it fails before scaffold exists.
- [ ] Add package/config/public bridge files.
- [ ] Add typed service adapter.
- [ ] Run structure test and source safety checks.

### Task 2: Add design tokens, theme state, and UI primitives

**Files:**
- Create: `frontend-vue/src/styles/{tokens,themes,base}.css`
- Create: `frontend-vue/src/stores/preferences.ts`
- Create: `frontend-vue/src/components/ui/{AppButton,IconButton,AppCard,AppBadge}.vue`

**Interfaces:**
- Produces: `data-theme=light|dark`, persisted theme preference and reusable semantic controls.

- [ ] Add static contract test for theme tokens and reduced-motion support.
- [ ] Implement theme store and primitives.
- [ ] Re-run contracts.

### Task 3: Add auth store and login page

**Files:**
- Create: `frontend-vue/src/stores/auth.ts`
- Create: `frontend-vue/src/layouts/AuthLayout.vue`
- Create: `frontend-vue/src/pages/LoginPage.vue`

**Interfaces:**
- Consumes: `legacyApi.init/signInCode/loadState/signOut`.
- Produces: reactive `currentUser`, initial legacy state and auth readiness.

- [ ] Add auth source contract test.
- [ ] Implement bootstrap/login/logout/error states.
- [ ] Build responsive login with existing favicon/hero and theme toggle.

### Task 4: Add router, permissions, and app shell

**Files:**
- Create: `frontend-vue/src/app/pinia.ts`, `frontend-vue/src/app/router/index.ts`
- Create: `frontend-vue/src/stores/context.ts`
- Create: `frontend-vue/src/layouts/AppShell.vue`
- Create: `frontend-vue/src/components/layout/{SidebarNav,TopBar}.vue`
- Create: `frontend-vue/src/features/navigation/navigation.ts`

**Interfaces:**
- Produces: role-filtered hash routes and immediate class/week context selection.

- [ ] Write pure navigation role test and verify RED.
- [ ] Implement role navigation model and guards.
- [ ] Implement responsive shell with always-visible Lucide icons.
- [ ] Run navigation test.

### Task 5: Move current-week server data to Vue Query

**Files:**
- Create: `frontend-vue/src/app/query-client.ts`
- Create: `frontend-vue/src/features/weeks/{queries.ts,week-lifecycle.ts,useWeekLifecycle.ts}`
- Test: `frontend-vue/tests/week-lifecycle.test.mjs`

**Interfaces:**
- Consumes: `legacyApi.loadWeekData` and initial legacy week metadata.
- Produces: query key `['week-data', classId, weekId]`, preload of next week, immediate week-id transition.

- [ ] Write pure lifecycle tests for rolling two-week-open semantics.
- [ ] Implement pure boundary calculation.
- [ ] Implement Vue Query hook with prefetch and realtime invalidation entrypoint.
- [ ] Implement lifecycle timer that changes selected week before fetching.
- [ ] Compile and run pure lifecycle tests.

### Task 6: Dashboard checkpoint

**Files:**
- Create: `frontend-vue/src/pages/DashboardPage.vue`
- Create: `frontend-vue/src/features/dashboard/dashboard-model.ts`
- Create: placeholder pages for remaining routes to prove navigation without migrating business logic yet.

**Interfaces:**
- Consumes: auth/context/week query state.
- Produces: welcome hero, KPI cards and current week context without global renderer.

- [ ] Add dashboard model test.
- [ ] Implement dashboard and placeholders.
- [ ] Verify route map contains every existing major page.

### Task 7: App bootstrap and realtime lifecycle

**Files:**
- Create: `frontend-vue/src/main.ts`, `frontend-vue/src/App.vue`
- Create: `frontend-vue/src/realtime/useRealtimeInvalidation.ts`

**Interfaces:**
- Consumes: `legacyApi.subscribeRealtime`.
- Produces: centralized query invalidation instead of DOM mutation.

- [ ] Implement bootstrap order: Pinia -> auth bootstrap -> router -> Vue Query -> mount.
- [ ] Subscribe realtime only while authenticated and unsubscribe on logout/unmount.
- [ ] Invalidate affected query keys for registration/structural changes.

### Task 8: Verification and recovery artifact

**Files:**
- Create: `frontend-vue/README.md`
- Create: `docs/superpowers/checkpoints/V8.6.0-CP1-STATUS.md`

- [ ] Run all Node/TypeScript structural and pure-function tests.
- [ ] Run JavaScript safety scan and verify legacy `frontend/` hashes did not change.
- [ ] Attempt `npm install`, `npm test`, and `npm run build`; record exact blocker if registry remains unavailable.
- [ ] Package `frontend-vue/` plus checkpoint status without claiming an unrun build.
