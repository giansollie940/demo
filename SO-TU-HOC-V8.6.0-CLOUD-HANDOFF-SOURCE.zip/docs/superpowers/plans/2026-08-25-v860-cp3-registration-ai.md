# V8.6.0 CP3 Registration and AI Review Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver production Vue student registration and teacher AI-review workflows with vanilla parity.

**Architecture:** Pure registration models derive eligibility/actions from fixed inputs. Injected mutation/orchestration adapters call the existing bridge, reload canonical state, hydrate context, and invalidate queries. Pages use local dialog drafts and shared CP2 UI/dirty infrastructure.

**Tech Stack:** Vue 3, TypeScript, Pinia, TanStack Vue Query, Vitest, Node tests, Lucide Vue, existing Supabase bridge.

**Spec:** `docs/superpowers/specs/2026-08-25-v860-cp3-registration-ai-design.md`

## Global Constraints

- No backend/RLS/RPC/Edge Function/Auth/AI-contract changes.
- Preserve all registration eligibility and teacher-action rules from vanilla.
- RED/GREEN before production code.
- No Git metadata; record SHA-256 checkpoints instead of commits.

---

### Task 1: Complete registration and bridge types

**Files:**
- Modify: `frontend-vue/src/types/legacy.ts`
- Create: `frontend-vue/tests/types/cp3-contracts.ts`

**Produces:** Complete `RegistrationRecord`, `EmergencyRegistrationInput`, and typed bridge methods for revision, emergency, AI, rereview, delete, and notification-read.

- [ ] Write compile-contract RED.
- [ ] Run `tsc` fixture and confirm missing members.
- [ ] Add minimal types/signatures.
- [ ] Run fixture and `npm run typecheck` GREEN.
- [ ] Record hashes.

### Task 2: Pure registration eligibility and manager-action model

**Files:**
- Create: `frontend-vue/src/features/registrations/registration-model.ts`
- Create: `frontend-vue/tests/unit/registration-model.spec.ts`

**Produces:** Deadline/session helpers, `deriveRegistrationEligibility`, `effectiveRegistrationStatus`, `registrationManagerActions`, and filter predicates.

- [ ] Write fixed-time RED tests for new/edit/approved/revision/overdue/emergency/started cases.
- [ ] Implement minimal pure model.
- [ ] Run single and full unit GREEN.
- [ ] Record hashes.

### Task 3: Registration save and AI orchestration

**Files:**
- Create: `frontend-vue/src/features/registrations/registration-mutations.ts`
- Create: `frontend-vue/tests/unit/registration-mutations.spec.ts`

**Produces:** `saveRegistrationMutation`, `submitRegistrationWithAi`, `createEmergencyRegistrationWithAi`, and `cancelEmergencyRegistration`.

- [ ] Write RED tests for source immutability, draft save, approved reset, pending AI, fallback, emergency reason, and reload order.
- [ ] Implement with injected bridge runtime.
- [ ] Run GREEN and typecheck.
- [ ] Record hashes.

### Task 4: Student registration components and page

**Files:**
- Create: `frontend-vue/src/components/registrations/RegistrationStatusBadge.vue`
- Create: `frontend-vue/src/components/registrations/StudySessionCard.vue`
- Create: `frontend-vue/src/components/registrations/RegistrationDialog.vue`
- Create: `frontend-vue/src/pages/RegistrationPage.vue`
- Modify: `frontend-vue/src/app/router/routes.ts`
- Test: `frontend-vue/tests/unit/registration-components.spec.ts`

- [ ] Write SSR/route RED tests for semantics, labels, validation, and real route component.
- [ ] Implement responsive cards/dialog/page.
- [ ] Integrate local draft, dirty/server-change banner, save/AI states.
- [ ] Run component/unit/typecheck/build GREEN.
- [ ] Record hashes.

### Task 5: Teacher approval mutations

**Files:**
- Create: `frontend-vue/src/features/approvals/approval-model.ts`
- Create: `frontend-vue/src/features/approvals/approval-mutations.ts`
- Create: `frontend-vue/tests/unit/approval-mutations.spec.ts`

**Produces:** filter/count model, single/batch approve, comment, revision/AI-wrong, and delete orchestration.

- [ ] Write RED tests for action eligibility, filter counts, source immutability, and direct bridge actions.
- [ ] Implement minimal pure/mutation code.
- [ ] Run GREEN and typecheck.
- [ ] Record hashes.

### Task 6: Teacher Approval page

**Files:**
- Create: `frontend-vue/src/components/approvals/ApprovalFilters.vue`
- Create: `frontend-vue/src/components/approvals/ApprovalList.vue`
- Create: `frontend-vue/src/components/approvals/ApprovalDetail.vue`
- Create: `frontend-vue/src/pages/ApprovalPage.vue`
- Modify: `frontend-vue/src/app/router/routes.ts`
- Test: `frontend-vue/tests/unit/approval-components.spec.ts`

- [ ] Write SSR/route RED tests for filters, AI/emergency metadata, actions, and route.
- [ ] Implement master/detail desktop and stacked mobile page.
- [ ] Integrate actions, canonical reload, dirty comments, and errors.
- [ ] Run GREEN/typecheck/build.
- [ ] Record hashes.

### Task 7: Realtime, Hallmark, and responsive verification

**Files:**
- Modify: `frontend-vue/src/realtime/useRealtimeInvalidation.ts` only if query scoping needs refinement.
- Create/update visual harness and CP3 runtime measurements.

- [ ] Verify registration invalidation and dirty-dialog behavior.
- [ ] Run Hallmark static/contrast/responsive audit.
- [ ] Test 320/375/414/768/1280 widths and key interactions.
- [ ] Fix concrete findings and rerun gates.

### Task 8: CP3 final verification and artifact

**Files:**
- Modify version/README.
- Create: `docs/superpowers/checkpoints/V8.6.0-CP3-STATUS.md`

- [ ] Run `npm run typecheck`.
- [ ] Run `npm test`.
- [ ] Run `npm run test:unit`.
- [ ] Build production with default command or documented runner fallback.
- [ ] Verify configured `dist`, bridge hash, no source/node_modules.
- [ ] Package and read every entry of `SO-TU-HOC-V8.6.0-CP3-DIST-CONFIGURED-FINAL.zip`.
- [ ] Record exact SHA-256 and remaining routes.

