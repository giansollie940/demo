# V8.6.0 CP3 — Registration and AI Review Design

Date: 2026-08-25
Status: Approved under the user's uninterrupted full-migration authorization

## Goal

Replace `/register` and `/review` placeholders with Vue workflows that preserve every registration, AI, revision, emergency, teacher-review, and deletion rule from the vanilla app.

## Constraints

- No backend, schema, RLS, RPC, Edge Function, Auth, or AI-decision change.
- Existing `SupabaseService` methods remain authoritative.
- Do not duplicate Edge Function retry/decision logic in components.
- Student drafts survive network failure.
- Canonical state is reloaded after every server action.
- Realtime invalidates/refetches; it does not patch unrelated arrays.

## Registration eligibility

For each effective schedule slot, derive:

- week effective status;
- deadline datetime and whether it passed;
- session start datetime and whether it started;
- existing registration;
- overdue revision state;
- regular-create eligibility;
- edit eligibility;
- emergency-create eligibility;
- read-only reason.

Rules match vanilla:

- New regular registration: open week, before deadline, before session, no existing row.
- Draft/submitted edit: open week, before deadline, before session.
- Approved edit: open week, before deadline, before session; saving resets approval/AI state and resubmits.
- Needs-revision edit: allowed after deadline but only before session start and while not revision-overdue.
- Emergency create: no existing row, open week, deadline passed, session not started.
- Revision-overdue or started sessions are read-only.

## Student registration page

- Effective schedule cards for selected week.
- Status, day/date, period time, deadline, content, device use, teacher feedback, AI result, emergency reason.
- Clear action label: register, edit, revise, view, emergency, or locked reason.
- Registration dialog with content, note/goal, device choice, validation, and status-specific guidance.
- Save draft when allowed.
- Submit for review.
- Approved edits resubmit and reset prior approval/AI fields.
- AI pending indicator and fallback to teacher review when AI fails.
- Emergency dialog adds required reason and uses the existing Edge Function.
- Student may cancel an emergency registration only before the session, through `deleteRegistration`.

## AI orchestration

After a submitted registration is persisted and canonical state reloaded:

- If `aiReviewStatus !== 'pending'`, finish with the current server state.
- If pending, call existing `requestAiReview(registrationId)`.
- Reload canonical state after the call.
- Display AI-approved, AI-requested-revision, teacher-queue, or AI-fallback result.
- Do not reimplement retry: the bridge already retries eligible failures once.

## Teacher approval page

Filters:

- Attention
- Approved
- Needs revision
- All

Sections/metadata:

- pending AI count;
- emergency count;
- student and slot identity;
- content/note/device use;
- AI decision/reason/confidence;
- teacher comment;
- effective status.

Actions preserve vanilla eligibility:

- Approve single.
- Approve all currently eligible rows.
- Request revision before session start.
- Save teacher comment.
- “AI chưa đúng” invokes the same revision RPC with required teacher guidance.
- Soft-delete through `deleteRegistration`.

## State and mutation design

- Pure models own status/eligibility/filtering and never read DOM.
- Registration save mutations clone current `LegacyState` and use `syncState`.
- Direct bridge actions are injected at the network boundary for tests.
- Pages keep local dialog drafts and do not mutate `auth.legacyState` before success.
- Save failure retains the dialog draft and error.
- Successful operations reload, hydrate, and invalidate week data.

## Realtime/conflict behavior

- Registration events invalidate `['week-data']`.
- An open dirty registration dialog receives a server-change warning.
- Canonical state may reload, but local fields are not replaced silently.
- Continuing a draft applies it to the latest canonical state on save.

## Responsive/accessibility

- Desktop registration cards use a varied grid; mobile stacks.
- Approval uses master/detail on desktop and filter/list/detail stack on mobile.
- All dialogs have labels, helper/error slots, keyboard close, and focus restoration.
- Status is text + icon, not color only.
- Actions are one line and at least 44px tall.
- 320/375/414/768/1280 widths have no horizontal overflow.

## Tests

- Pure deadline/session/eligibility tests with fixed Vietnam timestamps.
- Draft/approved/revision/emergency mutation tests.
- AI orchestration pending/success/failure tests.
- Manager action eligibility tests.
- Filter and batch-approve tests.
- SSR component semantics and route model tests.
- Full Node/unit/typecheck/build gates and configured DIST integrity.

## Completion

- `/register` and `/review` no longer use `ComingSoonPage`.
- All listed student and teacher actions are implemented.
- AI and emergency calls use existing bridge contracts.
- No backend file changes.
- Full gates and responsive audit pass.

