# SỔ TỰ HỌC V8.6.0 — Complete Vue Migration Design

Date: 2026-08-24
Status: Approved by the user for uninterrupted implementation
Baseline: V8.6.0 CP1 Vue Foundation, with the deployed vanilla application retained as rollback

## 1. Objective

Finish the Vue 3 migration until the Vue application has functional parity with the existing vanilla SỔ TỰ HỌC application, while improving responsiveness, accessibility, state isolation, and perceived performance.

The vanilla application is the canonical interaction and business-behavior reference. Small UX changes are allowed when they remove ambiguity, prevent destructive behavior, or make the application smoother, but they must not change backend authority or business rules.

The user explicitly authorized continuous implementation without additional approval prompts for minor design and engineering choices.

## 2. Binding constraints

- Do not change PostgreSQL schema, RLS, grants, RPC, Auth behavior, Edge Functions, AI-review contracts, or root-admin uniqueness.
- Do not expose service-role, secret, database, JWT, or Edge Function credentials to the browser.
- Keep `public/supabase-service.js` as the backend bridge unless a frontend-only compatibility extension is unavoidable.
- Preserve the configured `public/config.js` without printing or copying its values into reports.
- Preserve the vanilla deployment and the unconfigured/configured CP1 ZIPs as rollback artifacts.
- Use Vue Router hash history and Vite `base: './'` for GitHub Pages.
- Pinia owns authentication, selected class/week, preferences, and small UI state.
- Vue Query owns server-backed datasets and invalidation.
- Realtime events invalidate/refetch canonical data; components do not maintain competing server truth.
- Every checkpoint must pass typecheck, tests, and production build before advancing.

## 3. Canonical sources

Behavior reference:

- V8.5.x vanilla `app.js` renderers, binders, validation, status mapping, role rules, and error text.
- V8.6.0 CP1 `public/supabase-service.js` contract and its current tables/RPC/Edge Function calls.
- Current Vue CP1 lifecycle, auth, context, navigation, query keys, design tokens, and responsive shell.

When Vue and vanilla behavior differ unintentionally, vanilla wins unless the difference is an explicitly documented safety or usability improvement.

## 4. Architecture

```text
Supabase/Auth/Database/Realtime/Edge Functions
                    ↓
        window.SupabaseService bridge
                    ↓
        typed frontend adapter layer
                    ↓
     Vue Query        Pinia        pure models
         ↓              ↓               ↓
      feature composables and mutations
                    ↓
             Vue pages/components
```

Pages never write directly to Supabase tables. A mutation clones the latest server state, validates and applies only its owned fields, calls the bridge, reloads canonical state, hydrates context, and invalidates affected queries.

No optimistic success is shown for management operations. Failed saves retain the local draft.

## 5. Shared application infrastructure

Add shared components as they become necessary:

- `PageHeader`
- `AppTabs`
- `AppDialog` and `ConfirmDialog`
- `ToastHost`
- `SearchField`
- `FilterBar`
- `EmptyState`
- `ErrorState`
- `SkeletonBlock`
- responsive data table/card primitives
- dirty-state navigation guard

Functional icons use Lucide. Status meaning is never color-only. All icon-only actions have labels. Motion honors `prefers-reduced-motion`.

## 6. CP2 — Weekly Management and Schedule

### 6.1 Routes

- Replace `/weeks` placeholder with `WeeksPage.vue`.
- Replace `/schedule` placeholder with `SchedulePage.vue`.
- Keep both routes limited to `teacher` and `admin`.
- Only `admin` may change the Week 1 anchor or call `teacherRebaseWeeks`.

### 6.2 Weekly Management

The page provides:

- class/year context;
- lifecycle summary counts;
- current operational week action;
- filters for all/open/locked/upcoming/holiday;
- admin-only Week 1 anchor editor;
- per-week card/accordion;
- holiday toggle;
- `per_session_20` or `specific` deadline mode;
- specific datetime validation;
- view-week and open-schedule actions;
- dirty-state protection;
- inline success/error states.

Operational status remains a pure calculation:

- prior weeks: `locked`;
- operational and following week: `open`;
- later weeks: `upcoming`;
- explicit holiday: `holiday`.

### 6.3 Schedule

The schedule page has explicit tabs:

- Default Schedule
- Week-specific Schedule for the selected week

Default schedule changes only `state.schedule`; all overrides remain intact.

Creating a week-specific schedule clones the effective default schedule into a local draft. Saving replaces overrides only for the selected week. Resetting a week to default removes only that week's overrides after confirmation.

An empty schedule is invalid; a no-study week must be marked Holiday.

Desktop uses a five-day matrix. Mobile uses day tabs with period rows. Slot buttons use `aria-pressed`.

All slots are normalized, deduplicated, validated against available periods, and sorted by day/period.

### 6.4 CP2 mutation rules

- `saveWeekSettings` owns only class-week status/deadline/note fields.
- `rebaseWeekCalendar` calls the existing admin bridge method.
- `saveDefaultSchedule` preserves all week overrides.
- `saveWeekSchedule` preserves every other week's override.
- `resetWeekSchedule` removes only selected-week overrides.
- Successful mutations reload state and invalidate week queries.
- Realtime updates never overwrite a dirty draft silently.

## 7. CP3 — Registration and AI Review

Replace `/register` and `/review` placeholders.

Registration parity includes:

- effective schedule for selected week;
- deadline and session-start enforcement;
- draft/submitted/approved/needs-revision states;
- content, note, and electronic-device fields;
- emergency registration where existing rules permit it;
- AI review initiation and status;
- teacher feedback and revision history;
- deletion rules and confirmations;
- no change to AI decision thresholds or Edge Function contracts.

Approval parity includes:

- attention/approved/revision/all filters;
- pending AI indicator;
- emergency section;
- approve, request revision, comment, delete, and “AI wrong” actions where currently allowed;
- master/detail desktop layout and stacked mobile layout;
- realtime invalidation instead of local DOM edits.

## 8. CP4 — Class Tracking

Replace `/tracking` placeholder with:

- session overview cards;
- registered/missing/attention counts and progress;
- selected session detail;
- desktop status lanes;
- mobile status tabs;
- search/filter/sort;
- manager actions matching vanilla permissions;
- stale-response protection when class/week/session changes quickly.

## 9. CP5 — Students and Accounts

Replace `/students` placeholder while preserving:

- search, role, and active/deleted filters;
- create/update student and monitor accounts;
- reset password;
- activate/deactivate where supported;
- soft delete and restore;
- root-admin restrictions;
- class scoping;
- responsive table/card presentation.

## 10. CP6 — Root Admin

Replace `/admin` placeholder with areas for:

- overview;
- classes;
- teachers;
- permission assignments;
- root-admin transfer/protected operations already exposed by the bridge.

Use a scannable teacher × class permissions matrix. Never weaken backend checks because a control is hidden in the UI.

## 11. CP7 — Statistics, History, Comments, and Settings

Replace the remaining placeholders:

- `/statistics`: KPI, trends, and detail hierarchy;
- `/history`: chronological activity/audit timeline;
- `/comments`: teacher feedback grouped by week/session;
- `/settings`: logical tabs for class/application/AI/deadline preferences.

Settings mutations only change fields already persisted by the bridge.

## 12. CP8 — Wise Owl and quote behavior

Rebuild the Owl as an isolated Vue feature using the existing layered assets and layout JSON.

Behavior:

- bounded pupils and subtle head movement;
- reduced-motion compliance;
- page/context-aware messages;
- urgent notifications before tips/quotes;
- no heavy duplicate fetches;
- stable daily dashboard quote;
- rotating local/online owl quote pool without immediate repeats where current contracts allow it.

No backend extension is required unless an existing endpoint already supports it; local rotation is the fallback.

## 13. Realtime and concurrency

- One authenticated realtime subscription per app shell.
- Class/week structural changes reload auth state and context.
- Registration events invalidate affected week data.
- Components unsubscribe on unmount/logout.
- Query keys include class/week/session scope where needed.
- Rapid context changes ignore stale responses.
- Dirty editors show a server-change banner instead of replacing local work.

## 14. Error and loading states

Every feature implements initial loading, background refresh, empty, ready, dirty, saving, success, and error states.

- Inline errors remain visible until resolved.
- Toasts confirm secondary actions but never carry the only critical error.
- Network save errors preserve drafts and offer retry.
- RLS errors are reported as permission/state failures; the UI never suggests disabling RLS.
- Destructive actions require specific confirmation labels.

## 15. Performance

- Avoid global rerenders and deep watchers on entire server state.
- Derive page models with computed values and pure functions.
- Use query cache and background invalidation.
- Prefetch the next operational week.
- Cancel/ignore stale context requests.
- Keep large tables filtered/paginated or virtualized only when measured data size requires it.
- Do not introduce a large component framework.

## 16. Accessibility and responsive behavior

- Keyboard-operable routes, menus, dialogs, tabs, and schedule slots.
- Visible focus rings and accessible labels.
- Dialog focus trap and focus restoration.
- Status includes icon/text, not color alone.
- Desktop, tablet, 320/375/414px mobile coverage.
- Data-dense desktop layouts convert to tabs/cards on mobile.

## 17. Testing strategy

Use strict RED/GREEN for every feature.

Pure unit tests cover:

- permission and role derivation;
- week lifecycle/deadline calculations;
- schedule normalization/diff/override preservation;
- registration status and action eligibility;
- class tracking aggregation;
- account soft-delete/restore models;
- query-key and context behavior;
- quote rotation/no-repeat.

Mutation tests inject a boundary adapter and assert the complete state clone passed to the bridge without mocking domain logic.

Route/component contracts verify real user-visible behavior where feasible. Playwright smoke flows are added for critical role workflows when browser/runtime access permits.

Final gates:

```text
npm run typecheck
npm test
npm run test:unit
npm run build
```

When the sandbox blocks Vite's default esbuild config loader, use the locally supported `--configLoader runner` and report the exact command.

## 18. Deployment and cutover

During migration:

- vanilla production remains at the current root;
- Vue remains under `/vue/`;
- every green checkpoint produces a source/status artifact and a configured DIST ZIP;
- configured artifacts contain only public browser configuration.

Cutover occurs only after parity and role workflow regression. Preserve the last vanilla artifact and the last known-good Vue parallel deployment for rollback.

## 19. Completion criteria

The Vue migration is complete only when:

- no production route still uses `ComingSoonPage`;
- all critical vanilla workflows have parity or a documented safer UX;
- permissions remain server-backed;
- realtime subscriptions do not duplicate;
- class/week switches do not leak stale data;
- management drafts survive save failures;
- all tests/typecheck/build gates pass;
- configured DIST deploys under GitHub Pages;
- vanilla remains recoverable until explicit cutover.

